package com.hexaware.dao;

import com.hexaware.dto.BankAccount;
import com.hexaware.myexceptions.AccountNumberInvalidException;
import com.hexaware.myexceptions.InsufficientFundsException;
import com.hexaware.myexceptions.NegativeAmountException;

public interface IServiceProvider {
    BankAccount searchAccount(long accountNumber) throws AccountNumberInvalidException;

    double checkBalance(long accountNumber) throws AccountNumberInvalidException;

    boolean deposit(long accountNumber, double amount) throws AccountNumberInvalidException, NegativeAmountException;

    boolean withdraw(long accountNumber, double amount) throws AccountNumberInvalidException, InsufficientFundsException, NegativeAmountException;

    boolean createAccount(BankAccount newAcc);

    boolean removeAccount(long accountNumber) throws AccountNumberInvalidException;
}
