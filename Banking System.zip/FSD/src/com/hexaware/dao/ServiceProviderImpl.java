package com.hexaware.dao;

import com.hexaware.dto.Bank;
import com.hexaware.dto.BankAccount;
import com.hexaware.myexceptions.AccountNumberInvalidException;
import com.hexaware.myexceptions.InsufficientFundsException;
import com.hexaware.myexceptions.NegativeAmountException;

public class ServiceProviderImpl implements IServiceProvider {
    private Bank myBank;

    public ServiceProviderImpl(Bank myBank) {
        this.myBank = myBank;
    }

    @Override
    public BankAccount searchAccount(long accountNumber) throws AccountNumberInvalidException {
        for (BankAccount account : myBank.getAccountList()) {
            if (account.getAccountNumber() == accountNumber) {
                return account;
            }
        }
        throw new AccountNumberInvalidException("Account not found with account number: " + accountNumber);
    }

    @Override
    public double checkBalance(long accountNumber) throws AccountNumberInvalidException {
        BankAccount reqAccount = searchAccount(accountNumber);
        return reqAccount.getBalance();
    }

    @Override
    public boolean deposit(long accountNumber, double amount) throws AccountNumberInvalidException, NegativeAmountException {
        if (amount <= 0) {
            throw new NegativeAmountException("Invalid deposit amount: " + amount);
        }

        BankAccount reqAccount = searchAccount(accountNumber);
        reqAccount.setBalance(reqAccount.getBalance() + amount);
        return true;
    }

    @Override
    public boolean withdraw(long accountNumber, double amount)
            throws AccountNumberInvalidException, InsufficientFundsException, NegativeAmountException {
        if (amount <= 0) {
            throw new NegativeAmountException("Invalid withdrawal amount: " + amount);
        }

        BankAccount reqAccount = searchAccount(accountNumber);

        if (reqAccount.getBalance() < amount) {
            throw new InsufficientFundsException("Insufficient funds for withdrawal. Balance: " + reqAccount.getBalance());
        }

        reqAccount.setBalance(reqAccount.getBalance() - amount);
        return true;
    }

    @Override
    public boolean createAccount(BankAccount newAcc) {
        myBank.getAccountList().add(newAcc);
        return true;
    }

    @Override
    public boolean removeAccount(long accountNumber) throws AccountNumberInvalidException {
        BankAccount reqAccount = searchAccount(accountNumber);
        myBank.getAccountList().remove(reqAccount);
        return true;
    }
}
