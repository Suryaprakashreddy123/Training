package com.hexaware.springcoredemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Vehicle t= new Car();
		Traveller obj = new Traveller(t);
		obj.startJourney();*/
		//Spring IOC containter supplied with java based configuaration
		ApplicationContext applicationContext= new AnnotationConfigApplicationContext(AppConfig.class);
		Car obj=applicationContext.getBean(Car.class);
		Bike obj1=applicationContext.getBean(Bike.class);
		Traveller obj2=applicationContext.getBean(Traveller.class);
		obj.move();
		obj1.move();
		obj2.startJourney();
	}

}
