package com.hexaware.databaseemail;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatabaseemailApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatabaseemailApplication.class, args);
	}

}
