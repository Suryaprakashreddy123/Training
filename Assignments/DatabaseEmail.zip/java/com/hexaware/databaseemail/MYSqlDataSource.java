package com.hexaware.databaseemail;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component("mySQL")
@Primary
public class MYSqlDataSource implements DataSource{

	@Override
	public void returnConnection() {
		
		System.out.println("Returning the MySql connection");
		
	}
	

}
