package com.hexaware.databaseemail;

public interface DataSource {
	public void returnConnection();
}
