package com.hexaware.databaseemail;


  import org.springframework.context.ApplicationContext; import
  org.springframework.context.annotation.AnnotationConfigApplicationContext;
  
  public class Client { public static void main(String[] args) {
  ApplicationContext a= new
  AnnotationConfigApplicationContext(AppConfig.class); EmailService
  e=a.getBean(EmailService.class); e.sendEmail();
  
  } }
 

