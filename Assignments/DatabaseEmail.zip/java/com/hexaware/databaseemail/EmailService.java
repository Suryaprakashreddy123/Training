package com.hexaware.databaseemail;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Component("emailService")
public class EmailService {
	private DataSource d1;

	@Autowired
	public EmailService(DataSource d1) {
		super();
		this.d1 = d1;
		System.out.println("Data Source has been injected");
		
	}
	public void sendEmail() {
		System.out.println("The email is sending");
		d1.returnConnection();
	}
}
