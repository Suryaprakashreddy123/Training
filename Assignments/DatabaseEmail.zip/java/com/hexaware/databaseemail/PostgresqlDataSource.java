package com.hexaware.databaseemail;

import org.springframework.stereotype.Component;

@Component("postgreSQL")
public class PostgresqlDataSource implements DataSource {

	@Override
	public void returnConnection() {
		
		System.out.println("Returining the Postgresql Database");

	}

}
