package com.hexaware.message;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.hexaware.message")
public class AppConfig {

}
