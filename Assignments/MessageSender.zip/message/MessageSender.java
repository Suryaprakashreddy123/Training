package com.hexaware.message;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

/*@Component
public class MessageSender {
	private MessageService messageService1;
	private MessageService messageService2;
	@Autowired
	public MessageSender(@Qualifier("smsService")MessageService messageService1,@Qualifier("emailService")MessageService messageService2) {
		super();
		this.messageService1 = messageService1;
		this.messageService2 = messageService2;
	}
	public void sendMessage(String m, String type) {
		if("email".equals(type))
		{
			this.messageService2.sendMessage(m);
		}
		else
		{
			this.messageService1.sendMessage(m);
		}
	}
	
}*/
@Component("messageSender")
public class MessageSender {
	@Autowired
	public void setMessageService1(@Qualifier("smsService") MessageService messageService1) {
		System.out.println("Setter based DI1");
		this.messageService1 = messageService1;
	}

	@Autowired
	public void setMessageService2(@Qualifier("emailService") MessageService messageService2) {
		System.out.println("Setter based DI2");
		this.messageService2 = messageService2;
	}

	private MessageService messageService1;
	private MessageService messageService2;

	public void sendMessage(String m, String type) {
		if ("email".equals(type)) {
			this.messageService2.sendMessage(m);
		} else {
			this.messageService1.sendMessage(m);
		}
	}

}
