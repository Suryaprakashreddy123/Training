package com.hexaware.message;
class Dependencya{}
class Dependencyb{}
class Dependencyc{}

public class Demo {
	Dependencya da;
	Dependencyb db;
	Dependencyc dc;
	public Demo(Dependencya da, Dependencyb db, Dependencyc dc) {
		super();
		this.da = da;
		this.db = db;
		this.dc = dc;
	}
	
	

}
