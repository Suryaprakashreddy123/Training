package com.hexaware.message;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String message="Hello World";
		ApplicationContext a= new AnnotationConfigApplicationContext(AppConfig.class);
		MessageSender o = a.getBean(MessageSender.class);
		o.sendMessage(message, "sms");
		o.sendMessage(message, "email");
		

	}

}
