package com.hexaware.assignment;
import java.util.Scanner;

public class CustomStringBuilder {

    private char[] value;
    private int size;
    private static final int DEFAULT_CAPACITY = 16;

    public CustomStringBuilder() {
        value = new char[DEFAULT_CAPACITY];
        size = 0;
    }

    public CustomStringBuilder(String initialString) {
        this();
        append(initialString);
    }

    public CustomStringBuilder append(String str) {
        ensureCapacity(size + str.length());
        for (char c : str.toCharArray()) {
            value[size++] = c;
        }
        return this;
    }

    public CustomStringBuilder insert(int index, String str) {
        if (index < 0 || index > size) {
            throw new IndexOutOfBoundsException("Index out of bounds");
        }

        ensureCapacity(size + str.length());

        
        for (int i = size - 1; i >= index; i--) {
            value[i + str.length()] = value[i];
        }

        for (int i = 0; i < str.length(); i++) {
            value[index + i] = str.charAt(i);
        }

        size += str.length();

        return this;
    }

    public CustomStringBuilder delete(int startIndex, int endIndex) {
        if (startIndex < 0 || endIndex >= size || startIndex > endIndex) {
            throw new IndexOutOfBoundsException("Invalid start or end index");
        }

        for (int i = endIndex + 1; i < size; i++) {
            value[startIndex + i - endIndex - 1] = value[i];
        }

        size -= (endIndex - startIndex + 1);

        return this;
    }

    @Override
    public String toString() {
        return new String(value, 0, size);
    }

    private void ensureCapacity(int minCapacity) {
        if (minCapacity > value.length) {
            int newCapacity = Math.max(value.length * 2, minCapacity);
            char[] newValue = new char[newCapacity];
            System.arraycopy(value, 0, newValue, 0, size);
            value = newValue;
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter initial string: ");
        String initialString = scanner.nextLine();

        CustomStringBuilder stringBuilder = new CustomStringBuilder(initialString);

        System.out.print("Enter string to append: ");
        String appendString = scanner.nextLine();
        stringBuilder.append(appendString);
        System.out.println("After appending: " + stringBuilder);

        System.out.print("Enter index for insertion: ");
        int insertIndex = scanner.nextInt();
        scanner.nextLine(); 
        System.out.print("Enter string to insert: ");
        String insertString = scanner.nextLine();
        stringBuilder.insert(insertIndex, insertString);
        System.out.println("After inserting: " + stringBuilder);

        System.out.print("Enter start index for deletion: ");
        int deleteStartIndex = scanner.nextInt();
        System.out.print("Enter end index for deletion: ");
        int deleteEndIndex = scanner.nextInt();
        stringBuilder.delete(deleteStartIndex, deleteEndIndex);
        System.out.println("After deleting: " + stringBuilder);

        scanner.close();
    }
}