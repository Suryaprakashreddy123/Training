package com.hexaware.assignment;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class StringSearchEngine {

    private String originalText;

    public StringSearchEngine(String originalText) {
        this.originalText = originalText;
    }

    public List<Integer> findAllOccurrences(String substring) {
        List<Integer> occurrences = new ArrayList<>();
        int index = originalText.indexOf(substring);

        while (index != -1) {
            occurrences.add(index);
            index = originalText.indexOf(substring, index + 1);
        }

        return occurrences;
    }

    public String highlightOccurrences(String substring) {
        String highlightedText = originalText;
        List<Integer> occurrences = findAllOccurrences(substring);

        for (int i = occurrences.size() - 1; i >= 0; i--) {
            int start = occurrences.get(i);
            int end = start + substring.length();
            highlightedText = highlightedText.substring(0, start) +
                    "$" + highlightedText.substring(start, end) + "$" +
                    highlightedText.substring(end);
        }

        return highlightedText;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the original text: ");
        String originalText = scanner.nextLine();
        StringSearchEngine searchEngine = new StringSearchEngine(originalText);

        System.out.print("Enter the substring to find: ");
        String substringToFind = scanner.nextLine();

        List<Integer> occurrences = searchEngine.findAllOccurrences(substringToFind);
        System.out.println("Occurrences of '" + substringToFind + "': " + occurrences);

        String highlightedText = searchEngine.highlightOccurrences(substringToFind);
        System.out.println("Highlighted Text: " + highlightedText);

        
        System.out.println();

        scanner.close();
    }
}
